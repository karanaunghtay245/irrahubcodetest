package response

import (
	"encoding/json"
	"mtdnews/model"
	"net/http"
)

// JSON response message
// Case 1000, all success case
func ServiceResponseJSON(w http.ResponseWriter, responseCode int, errorMessage interface{}, responseBody interface{}) {
	var responseMessage interface{}
	switch responseCode {
	case 1000:
		responseMessage = "Request was successful"
	case 2000:
		responseMessage = errorMessage
	}
	response := model.Response{ResponseCode: responseCode, ResponseMessage: responseMessage, ResponseBody: responseBody}
	responseBytes, _ := json.Marshal(response)
	_, _ = w.Write(responseBytes)
}
