package main

import (
	"log"

	"authservice/config"

	"authservice/controller"
)

// Init function
// Start running from init
func init() {

}

// Main function of the whole project
func main() {
	config := config.GetConfig()
	controller := &controller.App{}
	controller.Initialize(config)
	log.Println("Listening...")
	controller.Run(":8081")
}
