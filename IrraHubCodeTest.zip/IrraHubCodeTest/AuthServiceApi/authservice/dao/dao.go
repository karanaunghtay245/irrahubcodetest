package dao

import (
	"net/http"

	"authservice/model"
	"authservice/response"
	"encoding/json"
	"github.com/google/uuid"
	"github.com/jinzhu/gorm"
)

// Registration with information by user enter
// Name, Email and password
func Registration(db *gorm.DB, w http.ResponseWriter, r *http.Request) {
	// Parse input JSON
	authInformation := model.AuthInformation{}
	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&authInformation); err != nil {
		response.ServiceResponseJSON(w, 2000, err.Error(), nil)
		return
	}
	defer r.Body.Close()

	if authInformation.UserName == "" || authInformation.Email == "" || authInformation.Password == "" {
		response.ServiceResponseJSON(w, 2000, "All User Information Must be Need", nil)
		return
	}

	authInformation.ID = uuid.New()

	if err := db.Save(&authInformation).Error; err != nil {
		response.ServiceResponseJSON(w, 2000, err.Error(), nil)
		return
	}
	response.ServiceResponseJSON(w, 1000, nil, nil)
}

// Login with Email and Password
func Login(db *gorm.DB, w http.ResponseWriter, r *http.Request) {
	// Parse input JSON
	var authInformation, authData model.AuthInformation
	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&authData); err != nil {
		response.ServiceResponseJSON(w, 2000, err.Error(), nil)
		return
	}
	defer r.Body.Close()

	if authData.Email == "" || authData.Password == "" {
		response.ServiceResponseJSON(w, 2000, "Must Need User Name and Password", nil)
		return
	}

	if err := db.First(&authInformation, model.AuthInformation{Email: authData.Email, Password: authData.Password}).Error; err != nil {
		response.ServiceResponseJSON(w, 2000, err.Error(), nil)
		return
	}

	if &authInformation == nil {
		response.ServiceResponseJSON(w, 2000, "No User Found With this Information", nil)
		return
	}
	response.ServiceResponseJSON(w, 1000, "Login is Successful", nil)
}
