package model

import (
	"github.com/google/uuid"
	"github.com/jinzhu/gorm"
	"time"

	_ "github.com/jinzhu/gorm/dialects/mysql"
)

type AuthInformation struct {
	ID        uuid.UUID `gorm:"primary"`
	UserName  string
	Email     string
	Password  string
	CreatedAt time.Time
	UpdatedAt time.Time
}

type Response struct {
	ResponseCode    int
	ResponseMessage interface{}
	ResponseBody    interface{}
}

// DBMigrate will create and migrate the tables, and then make the some relationships if necessary
func DBMigrate(db *gorm.DB) *gorm.DB {
	db.AutoMigrate(&AuthInformation{})
	return db
}
