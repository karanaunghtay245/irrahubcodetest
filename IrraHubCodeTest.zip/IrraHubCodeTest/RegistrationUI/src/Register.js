import React, { Component } from 'react';
import axios from 'axios';

class Register extends Component {
    constructor(props) {
        super(props);

        this.state = {
            fullName: '',
            email: '',
            password: ''
        };

        this.update = this.update.bind(this);

        this.displayLogin = this.displayLogin.bind(this);
    }

    update(e) {
        let name = e.target.name;
        let value = e.target.value;
        this.setState({
            [name]: value
        });
    }

    displayLogin(e) {
        e.preventDefault();
        console.log(this.state);
        const user = {
            UserName: this.state.fullName,
            Email:this.state.email,
            Password: this.state.password
        };

        // Calling Golang Api Endpoint to Save the Registration Information
        axios.post(`http://localhost:8081/api/register/v1`, { user })
            .then(res => {
                console.log(res);
                console.log(res.data);
                const responseCode = res['data']['ResponseCode']
                if (responseCode != "1000") {
                    alert("Check your input again")
                    this.setState({
                        fullName: '',
                        email: '',
                        password: ''
                    });
                }else{
                    alert('You have successfully registered')
                    this.setState({
                        fullName: '',
                        email: '',
                        password: ''
                    });
                }
            });

    }


    render() {
        return (
            <div className="register">
                <form onSubmit={this.displayLogin}>
                    <h2>Register</h2>

                    <div className="name">
                        <input
                            type="text"
                            placeholder="Full Name"
                            name="fullName"
                            value={this.state.fullName}
                            onChange={this.update}
                        />
                    </div>

                    <div className="email">
                        <input
                            type="text"
                            placeholder="Enter your email"
                            name="email"
                            value={this.state.email}
                            onChange={this.update}
                        />
                    </div>

                    <div className="password">
                        <input
                            type="password"
                            placeholder="Password"
                            name="password"
                            value={this.state.password}
                            onChange={this.update}
                        />
                    </div>

                    <div className="password">
                        <input type="password" placeholder="Confirm Password" name="passwordConfirm" />
                    </div>

                    <input type="submit" value="Register"  />
                </form>

            </div>
        );
    }
}

export default Register;