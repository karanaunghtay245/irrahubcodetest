import React, { Component } from 'react';
import axios from 'axios';

class Login extends Component {
	constructor(props) {
		super(props);

		this.state = {
			email: '',
			password: ''
		};

		this.update = this.update.bind(this);

		this.displayLogin = this.displayLogin.bind(this);
	}

	update(e) {
		let name = e.target.name;
		let value = e.target.value;
		this.setState({
			[name]: value
		});
	}

	displayLogin(e) {
		e.preventDefault();
        const user = {
            Email:this.state.email,
            Password: this.state.password
        };
   axios.post(`http://localhost:8081/api/login/v1`, { user })
            .then(res => {
                console.log(res);
                console.log(res.data);
                const responseCode = res['data']['ResponseCode']
                  if (responseCode != "1000"){
                 alert("User Name or password incorrect)

		this.setState({
			email: '',
			password: ''
		});
               }else{
             alert('Login Successful');
		
		this.setState({
			email: '',
			password: ''
		});
}

}

            });

		
	}

	render() {
		return (
			<div className="login">
				<form onSubmit={this.displayLogin}>
					<h2>Login</h2>
					<div className="username">
						<input
							type="text"
							placeholder="Email"
							value={this.state.email}
							onChange={this.update}
							name="email"
						/>
					</div>

					<div className="password">
						<input
							type="password"
							placeholder="Password"
							value={this.state.password}
							onChange={this.update}
							name="password"
						/>
					</div>

					<input type="submit" value="Login" />
				</form>

			</div>
		);
	}
}

export default Login;